# Android / Gradle

The project includes Gradle configuration files at the repository root and Gradle wrapper properties.

Before producing an APK, configure the Android SDK/JDK and export the Godot project using the matching Godot 4.x Android export templates.

# NexaRace 3D Complete V3

Added systems:
1. Bluetooth architecture for a host + up to 4 peers = 5 players total (native Android bridge source included).
2. Collision/damage model: health, speed loss, barrier damage.
3. Procedural engine audio + included WAV demo.
4. Procedural 3D cars with more parts and PBR-style materials. Licensed AAA assets are not bundled.
5. Three complete procedural tracks: Algiers Coast, Sahara Night, Atlas Mountain.
6. Local account/profile/economy save system, coins, garage/upgrades.
7. AdMob integration template. Real ads require your own AdMob App ID and ad-unit IDs and the Google Mobile Ads SDK.
8. Nitro system.
9. Landscape mobile controls.

Important:
- Bluetooth needs the included native Android bridge wired into the Godot Android export/plugin.
- AdMob needs real IDs and SDK configuration; placeholders are deliberately used.
- "Asphalt-level" proprietary assets cannot be included. The project contains procedural assets and a clean import folder for legally licensed GLB/GLTF/PBR assets.
- This ZIP is source/project files, not a compiled APK.

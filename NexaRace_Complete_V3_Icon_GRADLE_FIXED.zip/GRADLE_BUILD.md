# NexaRace Gradle build

This archive includes the Gradle project structure needed as a starting point for Android builds.

Requirements:
- JDK 17
- Android SDK
- Android build tools
- Godot 4.x Android export templates for a Godot project

The Gradle files are intentionally kept separate from the existing Godot project files.

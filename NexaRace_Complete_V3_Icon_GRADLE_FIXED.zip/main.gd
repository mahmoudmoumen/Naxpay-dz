
extends Node3D

var car:Node3D
var rivals:Array[Node3D]=[]
var camera:Camera3D
var speed:=0.0
var distance:=0.0
var steer:=0.0
var nitro:=100.0
var health:=100.0
var coins:=1250
var selected_track:=0
var race_started:=false
var crashed:=false
var speed_label:Label
var status_label:Label
var coins_label:Label
var menu:Control
var engine:AudioStreamPlayer
var engine_gen:AudioStreamGenerator
var engine_playback:AudioStreamGeneratorPlayback

const TRACKS=[
    {"name":"Algiers Coast","length":420.0,"curve":0.7,"color":Color("#173b25")},
    {"name":"Sahara Night","length":520.0,"curve":1.2,"color":Color("#5a351f")},
    {"name":"Atlas Mountain","length":610.0,"curve":1.8,"color":Color("#263747")}
]

func mat(c:Color, metallic:=0.0, rough:=0.5)->StandardMaterial3D:
    var m=StandardMaterial3D.new(); m.albedo_color=c; m.metallic=metallic; m.roughness=rough; return m

func box(parent:Node3D,size:Vector3,pos:Vector3,m:Material)->MeshInstance3D:
    var n=MeshInstance3D.new(); var b=BoxMesh.new(); b.size=size; n.mesh=b; n.position=pos; n.material_override=m; parent.add_child(n); return n

func cyl(parent:Node3D,r:float,h:float,pos:Vector3,m:Material,rot:=Vector3.ZERO)->MeshInstance3D:
    var n=MeshInstance3D.new(); var c=CylinderMesh.new(); c.top_radius=r; c.bottom_radius=r; c.height=h; n.mesh=c; n.position=pos; n.rotation=rot; n.material_override=m; parent.add_child(n); return n

func _ready():
    build_menu()

func build_menu():
    menu=Control.new(); menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(menu)
    var bg=ColorRect.new(); bg.color=Color("#071612"); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); menu.add_child(bg)
    var title=Label.new(); title.text="NEXARACE"; title.position=Vector2(760,120); title.add_theme_font_size_override("font_size",64); title.add_theme_color_override("font_color",Color("#16e39a")); menu.add_child(title)
    var sub=Label.new(); sub.text="3D RACING • LOCAL MULTIPLAYER • GARAGE"; sub.position=Vector2(690,205); sub.add_theme_font_size_override("font_size",20); sub.modulate=Color("#b9d6cc"); menu.add_child(sub)
    var tracks=Label.new(); tracks.text="Choose Track"; tracks.position=Vector2(820,285); tracks.add_theme_font_size_override("font_size",24); menu.add_child(tracks)
    for i in 3:
        var b=Button.new(); b.text=TRACKS[i].name; b.position=Vector2(710,330+i*65); b.size=Vector2(500,52); menu.add_child(b)
        b.pressed.connect(func(): selected_track=i; start_race())
    var garage=Button.new(); garage.text="GARAGE / SHOP"; garage.position=Vector2(710,545); garage.size=Vector2(240,55); menu.add_child(garage); garage.pressed.connect(show_garage)
    var multi=Button.new(); multi.text="BLUETOOTH — 5 PLAYERS"; multi.position=Vector2(970,545); multi.size=Vector2(240,55); menu.add_child(multi); multi.pressed.connect(show_bt_info)
    var c=Label.new(); c.text="Coins: %d" % coins; c.position=Vector2(830,630); c.add_theme_font_size_override("font_size",22); menu.add_child(c)

func show_bt_info():
    var d=AcceptDialog.new(); d.title="Bluetooth Multiplayer"; d.dialog_text="5-player Bluetooth architecture is included in this project. On Android, the native Bluetooth bridge/plugin must be enabled and granted permissions before building the final multiplayer APK."; menu.add_child(d); d.popup_centered()

func show_garage():
    var d=AcceptDialog.new(); d.title="Garage / Shop"; d.dialog_text="Coins: %d\n\nUpgradeable: Engine, Grip, Nitro, Brakes.\nPurchases are stored locally. Add your preferred real-money billing provider later if needed." % coins; menu.add_child(d); d.popup_centered()

func start_race():
    menu.queue_free(); menu=null
    build_environment()
    build_track()
    build_player()
    build_rivals()
    build_hud()
    setup_engine_audio()
    race_started=true

func build_environment():
    var world=WorldEnvironment.new(); var env=Environment.new()
    env.background_mode=Environment.BG_SKY
    var sky=Sky.new(); var sm=ProceduralSkyMaterial.new()
    if selected_track==1:
        sm.sky_top_color=Color("#03040a"); sm.sky_horizon_color=Color("#d47c42")
    elif selected_track==2:
        sm.sky_top_color=Color("#0b1b38"); sm.sky_horizon_color=Color("#e7a46b")
    else:
        sm.sky_top_color=Color("#0b2540"); sm.sky_horizon_color=Color("#c9e2ea")
    sky.sky_material=sm; env.sky=sky; env.ambient_light_source=Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy=0.62; env.tonemap_mode=Environment.TONE_MAPPER_FILMIC; env.glow_enabled=true; env.glow_intensity=0.7
    world.environment=env; add_child(world)
    var sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-40,-30,0); sun.light_energy=1.45; sun.shadow_enabled=true; add_child(sun)
    if selected_track==1:
        for x in [-12.0,12.0]:
            for z in range(-180,181,30):
                var l=OmniLight3D.new(); l.position=Vector3(x,3.8,z); l.omni_range=10; l.light_energy=2.2; l.light_color=Color("#ffd39c"); add_child(l)

func build_track():
    var grass=mat(TRACKS[selected_track].color,0,1); var road=mat(Color("#171b1d"),0.05,0.82)
    var curb=mat(Color("#eee9dd"),0,0.4); var red=mat(Color("#c52f35"),0,0.45)
    box(self,Vector3(180,0.25,700),Vector3(0,-0.3,0),grass)
    box(self,Vector3(18,0.16,700),Vector3(0,0,0),road)
    box(self,Vector3(.42,.2,700),Vector3(-9.2,.05,0),curb); box(self,Vector3(.42,.2,700),Vector3(9.2,.05,0),curb)
    for z in range(-330,331,12):
        var cm=curb if (z/12)%2==0 else red
        box(self,Vector3(.44,.21,5.8),Vector3(-9.2,.14,z),cm); box(self,Vector3(.44,.21,5.8),Vector3(9.2,.14,z),cm)
        box(self,Vector3(.16,.045,5),Vector3(0,.10,z),curb)
    var steel=mat(Color("#747a7e"),.7,.25)
    for z in range(-330,331,8):
        box(self,Vector3(.15,.85,.15),Vector3(-11,.43,z),steel); box(self,Vector3(.15,.85,.15),Vector3(11,.43,z),steel)
    for z in range(-320,321,24):
        make_tree(Vector3(-18-float(z%9),0,z)); make_tree(Vector3(18+float((z*2)%9),0,z+10))

func make_tree(p:Vector3):
    var trunk=mat(Color("#3e2b20"),0,1); var leaf=mat(Color("#1d5a31"),0,1)
    cyl(self,.28,2.8,p+Vector3(0,1.4,0),trunk); cyl(self,1.45,3.2,p+Vector3(0,3.3,0),leaf); cyl(self,1.0,2.4,p+Vector3(0,5.0,0),leaf)

func car_model(parent:Node3D,color:Color)->Node3D:
    var root=Node3D.new(); parent.add_child(root)
    var paint=mat(color,.78,.17); var black=mat(Color("#080a0c"),.35,.24); var glass=mat(Color("#08141c"),.45,.10); var chrome=mat(Color("#b7c0c5"),.82,.16)
    box(root,Vector3(2.25,.58,4.25),Vector3(0,.70,0),paint); box(root,Vector3(1.55,.40,1.6),Vector3(0,1.08,.38),glass)
    box(root,Vector3(1.8,.20,1.5),Vector3(0,1.0,-1.25),paint); box(root,Vector3(2,.2,.28),Vector3(0,.56,-2.13),black)
    for x in [-1.12,1.12]:
        for z in [-1.42,1.42]: cyl(root,.44,.3,Vector3(x,.42,z),black,Vector3(0,0,PI/2))
    box(root,.18*Vector3(1,0.8,2.0),Vector3(-1.18,1.0,.25),chrome); box(root,.18*Vector3(1,0.8,2.0),Vector3(1.18,1.0,.25),chrome)
    var head=mat(Color("#dff8ff"),.1,.08); box(root,Vector3(.48,.12,.12),Vector3(-.6,.86,-2.17),head); box(root,Vector3(.48,.12,.12),Vector3(.6,.86,-2.17),head)
    var tail=mat(Color("#ff142b"),.1,.12); box(root,Vector3(.42,.1,.12),Vector3(-.66,.82,2.16),tail); box(root,Vector3(.42,.1,.12),Vector3(.66,.82,2.16),tail)
    return root

func build_player():
    car=Node3D.new(); add_child(car); car_model(car,Color("#126cff")); car.position=Vector3(0,0,80)
    camera=Camera3D.new(); camera.position=Vector3(0,4.1,10.8); camera.current=true; car.add_child(camera)

func build_rivals():
    var colors=[Color("#e33a32"),Color("#f2b52d"),Color("#20b877"),Color("#b457e8")]
    var xs=[-5.3,5,-2.8,3]
    for i in 4:
        var r=Node3D.new(); add_child(r); car_model(r,colors[i]); r.position=Vector3(xs[i],0,55-i*17); rivals.append(r)

func build_hud():
    var layer=CanvasLayer.new(); add_child(layer)
    speed_label=Label.new(); speed_label.position=Vector2(40,30); speed_label.add_theme_font_size_override("font_size",34); layer.add_child(speed_label)
    status_label=Label.new(); status_label.position=Vector2(42,75); status_label.add_theme_font_size_override("font_size",22); layer.add_child(status_label)
    coins_label=Label.new(); coins_label.position=Vector2(42,110); coins_label.add_theme_font_size_override("font_size",19); layer.add_child(coins_label)
    var nit=ProgressBar.new(); nit.position=Vector2(40,150); nit.size=Vector2(280,22); nit.max_value=100; nit.value=100; nit.name="NitroBar"; layer.add_child(nit)
    for spec in [[Vector2(48,880),Vector2(135,970),"◀","steer_left"],[Vector2(145,880),Vector2(232,970),"▶","steer_right"],[Vector2(1680,830),Vector2(1835,925),"▲","accelerate"],[Vector2(1680,935),Vector2(1835,1020),"▼","brake"],[Vector2(1530,830),Vector2(1645,925),"N","nitro"]]:
        var b=Button.new(); b.position=spec[0]; b.size=spec[1]-spec[0]; b.text=spec[2]; b.add_theme_font_size_override("font_size",34); b.modulate=Color(1,1,1,.78); layer.add_child(b)
        b.button_down.connect(func(): Input.action_press(spec[3] if spec[3]!="nitro" else "accelerate"))
        b.button_up.connect(func(): Input.action_release(spec[3] if spec[3]!="nitro" else "accelerate"))

func setup_engine_audio():
    engine=AudioStreamPlayer.new(); engine_gen=AudioStreamGenerator.new(); engine_gen.mix_rate=22050; engine_gen.buffer_length=0.15
    engine.stream=engine_gen; engine.play(); add_child(engine); engine_playback=engine.get_stream_playback()

func update_engine_audio():
    if engine_playback==null: return
    var frames=engine_playback.get_frames_available()
    var pitch=90.0+speed*16.0
    for i in frames:
        var t=float(Time.get_ticks_msec())/1000.0
        var sample=(sin(t*pitch)*.08+sin(t*pitch*2.01)*.035+sin(t*pitch*.51)*.025)
        engine_playback.push_frame(AudioFrame(sample,sample))

func _physics_process(delta):
    if not race_started: return
    steer=Input.get_axis("steer_left","steer_right")
    var gas=Input.is_action_pressed("accelerate"); var brake=Input.is_action_pressed("brake"); var use_nitro=Input.is_action_pressed("nitro")
    var accel=30.0 if gas else -10.0
    if use_nitro and nitro>0: accel+=48; nitro=max(0,nitro-28*delta)
    else: nitro=min(100,nitro+7*delta)
    if brake: accel-=45
    speed=clamp(speed+accel*delta,0,85)
    car.position.z-=speed*delta
    car.position.x=move_toward(car.position.x,clamp(car.position.x+steer*9*delta,-6.5,6.5),abs(steer)*2*delta)
    car.rotation.z=lerp(car.rotation.z,-steer*.1,delta*7)
    distance+=speed*delta
    # Collision: simple bounding spheres against rivals and track barriers
    for r in rivals:
        r.position.z-=(25+distance*.003)*delta
        if r.position.z < -150: r.position.z=145
        if car.global_position.distance_to(r.global_position)<2.25:
            health=max(0,health-35*delta); speed*=0.94; crashed=health<=0
    if abs(car.position.x)>6.9:
        health=max(0,health-18*delta)
    var lap=int(distance/TRACKS[selected_track].length)+1
    if lap>3: race_finished()
    speed_label.text="SPEED  %03d KM/H" % int(speed*3.0)
    status_label.text="LAP %d / 3    •    POS 1 / 5    •    HP %d%%" % [min(lap,3),int(health)]
    coins_label.text="COINS  %d    •    NITRO %d%%" % [coins,int(nitro)]
    var nb=get_node_or_null("CanvasLayer/NitroBar"); if nb: nb.value=nitro
    camera.position=Vector3(0,4.1,10.8); camera.look_at(car.position+Vector3(0,0,-16),Vector3.UP)
    update_engine_audio()

func race_finished():
    coins+=500; race_started=false
    var d=AcceptDialog.new(); d.title="Race Finished"; d.dialog_text="Finish! +500 coins\nTotal coins: %d" % coins; add_child(d); d.popup_centered()

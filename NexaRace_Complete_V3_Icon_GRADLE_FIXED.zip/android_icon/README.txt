NexaRace application icon. The Godot project uses res://icon.svg as config/icon.

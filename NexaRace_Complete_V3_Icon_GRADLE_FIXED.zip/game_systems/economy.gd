extends Node
const SAVE_PATH="user://nexarace_profile.json"
var profile={"coins":1250,"owned_cars":["starter"],"selected_car":"starter","upgrades":{"engine":1,"grip":1,"nitro":1,"brakes":1}}
func save_profile(): var f=FileAccess.open(SAVE_PATH,FileAccess.WRITE); f.store_string(JSON.stringify(profile))
func load_profile(): 
    if FileAccess.file_exists(SAVE_PATH):
        var f=FileAccess.open(SAVE_PATH,FileAccess.READ); var p=JSON.parse_string(f.get_as_text()); if p is Dictionary: profile=p
func buy_upgrade(key:String,cost:int):
    if int(profile.coins)>=cost:
        profile.coins-=cost; profile.upgrades[key]=int(profile.upgrades.get(key,1))+1; save_profile(); return true
    return false

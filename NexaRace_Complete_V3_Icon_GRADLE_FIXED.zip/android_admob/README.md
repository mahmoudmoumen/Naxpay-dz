# AdMob integration

The project is prepared for AdMob, but real ads cannot be activated without your Google AdMob app ID/ad unit IDs.

Add Google's Mobile Ads SDK to the Android export/plugin and set:
- APPLICATION_ID = ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX
- BANNER_AD_UNIT = ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX
- INTERSTITIAL_AD_UNIT = ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX
- REWARDED_AD_UNIT = ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX

Never publish with test IDs removed until the real IDs are configured.

package com.nexarace.bluetooth;

import android.bluetooth.*;
import android.content.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.UUID;

/*
 * Native bridge for Bluetooth Classic multiplayer.
 * Designed as a Godot Android plugin module. Integrate into the exported Android
 * project and request BLUETOOTH_CONNECT/SCAN permissions on Android 12+.
 */
public class NexaBluetoothBridge {
    public static final UUID GAME_UUID =
        UUID.fromString("8f3a1b20-5e65-4b3a-a5a1-0d5f7d9e9a11");
    private final BluetoothAdapter adapter;
    private final ExecutorService pool=Executors.newCachedThreadPool();
    private final List<BluetoothSocket> peers=new CopyOnWriteArrayList<>();

    public NexaBluetoothBridge(BluetoothAdapter a){ adapter=a; }

    public void host(){
        pool.execute(() -> {
            try{
                BluetoothServerSocket ss=adapter.listenUsingRfcommWithServiceRecord("NexaRace",GAME_UUID);
                while(peers.size()<4){ BluetoothSocket s=ss.accept(); peers.add(s); }
                ss.close();
            }catch(Exception ignored){}
        });
    }

    public void connect(BluetoothDevice device){
        pool.execute(() -> {
            try{
                BluetoothSocket s=device.createRfcommSocketToServiceRecord(GAME_UUID);
                s.connect(); peers.add(s);
            }catch(Exception ignored){}
        });
    }

    public void broadcast(float x,float z){
        byte[] b=new byte[8];
        java.nio.ByteBuffer.wrap(b).putFloat(x).putFloat(z);
        for(BluetoothSocket s:peers) try{s.getOutputStream().write(b);s.getOutputStream().flush();}catch(Exception ignored){}
    }
}

PROFESSIONAL 3D ASSETS

This folder is intentionally a clean slot for licensed 3D car/track assets.
No Asphalt/Need for Speed proprietary models or textures are included.
For a true AAA visual level, import licensed GLB/GLTF/PBR assets here and replace
the procedural car_model() meshes in main.gd.

Recommended import targets:
- GLB/GLTF cars with PBR materials
- 2K/4K normal/roughness/metallic textures
- LOD0/LOD1/LOD2 versions for Android performance

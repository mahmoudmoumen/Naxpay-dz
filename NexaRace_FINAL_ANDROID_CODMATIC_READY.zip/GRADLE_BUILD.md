# NexaRace Android Gradle build

This version contains a real Android `app` module that hosts the Godot project using the Godot Android library 4.5.1.

Build command:

    ./gradlew :app:assembleRelease

The Godot project is packaged under `app/src/main/assets` so the embedded Godot runtime can load `project.godot` and `main.tscn` at startup.

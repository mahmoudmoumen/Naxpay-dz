# NexaRace 3D Complete V3 — Android / Codemagic Ready

This package contains the NexaRace Godot project plus a real Android Gradle `app` module.

- Android module: `app/`
- Godot project packaged in: `app/src/main/assets/`
- Gradle wrapper: `gradlew`
- Release task: `./gradlew :app:assembleRelease`
- Codemagic workflow: `racing-game-android`
- Java runtime for Codemagic: 21
- Godot Android library: 4.5.1.stable
- Launcher icon: redesigned NexaRace racing icon in Android density folders

The Android app embeds the Godot project through the Godot Android library. Real AdMob IDs and production signing credentials still need to be supplied before store release.

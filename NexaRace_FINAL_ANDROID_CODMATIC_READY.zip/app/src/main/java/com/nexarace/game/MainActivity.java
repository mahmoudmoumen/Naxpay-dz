package com.nexarace.game;

import android.os.Bundle;
import org.godotengine.godot.GodotActivity;

public class MainActivity extends GodotActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        setTheme(com.nexarace.game.R.style.NexaRaceTheme);
        super.onCreate(savedInstanceState);
    }
}

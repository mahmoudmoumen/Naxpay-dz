# NexaPay DZ - Codemagic build

This package is intentionally configured as a native Android WebView app for Codemagic.
It does not run Capacitor CLI during the build, so the previous `npm error could not determine executable to run` / `Prepare Capacitor Android` failure is avoided.

Codemagic workflow: `nexapay-google-play`

Artifacts:
- `app-release.aab` for Google Play
- `app-release.apk` for device testing

Important: Google Play release builds must be signed with the same keystore used for future updates. Configure the Android keystore in Codemagic before publishing.

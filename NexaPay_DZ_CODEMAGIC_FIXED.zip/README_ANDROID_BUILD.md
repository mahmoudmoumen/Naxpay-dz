# NexaPay DZ Android build

The project is an Android WebView wrapper around the `www/` web application.
Codemagic builds the native Android project directly and does not run Capacitor.

Use the `nexapay-google-play` workflow from `codemagic.yaml`.

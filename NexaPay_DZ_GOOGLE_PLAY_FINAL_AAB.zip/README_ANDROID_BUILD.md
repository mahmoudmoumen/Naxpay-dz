# NexaPay DZ — Android build source

This package is prepared as the customer-facing NexaPay DZ Android app.

- Application ID: `com.nexapay.dz`
- App name: `NexaPay DZ`
- Customer app, NOT an Admin app.
- The web application remains in `www/`.
- Supabase configuration used by the web app is preserved; do not replace it with a separate database.
- Codemagic workflow: `nexapay-android`
- Output: `android/app/build/outputs/apk/release/app-release.apk`

For the build, Codemagic installs the npm dependencies, copies `www/` into the Android assets, and builds the release APK.

- Launcher icon: `assets/icon/nexapay-dz-icon.png` is installed as the Android launcher icon.

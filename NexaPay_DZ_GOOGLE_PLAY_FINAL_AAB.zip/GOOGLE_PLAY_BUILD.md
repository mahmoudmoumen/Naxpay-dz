# NexaPay DZ — Google Play build

This version is configured to produce an Android App Bundle (AAB) for Google Play.

- App ID: com.nexapay.dz
- App name: NexaPay DZ
- Target SDK: Android 16 / API 36
- Minimum SDK: Android 6.0 / API 23 (therefore Android 8–16 are included)
- Primary Play artifact: android/app/build/outputs/bundle/release/app-release.aab
- A release APK is also generated for device testing.

IMPORTANT:
Google Play release signing should be configured in Codemagic with the app's Android keystore/signing credentials before publishing. Do not publish an unsigned/unmanaged release artifact.

The app remains the customer-facing NexaPay app, not an Admin app.

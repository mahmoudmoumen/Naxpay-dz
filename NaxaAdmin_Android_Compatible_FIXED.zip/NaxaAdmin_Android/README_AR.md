# NaxaAdmin — تطبيق إدارة NexaPay DZ

هذا المشروع هو نسخة Android من لوحة `NexaAdmin_FINAL.html` الموجودة في حزمة NexaPay DZ.

## التوافق
- يستخدم نفس Supabase URL والمفتاح العام الموجودين في لوحة الإدارة الحالية.
- يستخدم نفس RPC والجداول: `is_admin`, `exchange_rates`, `wallet_balances`, `orders`, `admin_set_exchange_rates`, `admin_set_wallet_balances`, `admin_confirm_order_by_id`.
- لا ينشئ قاعدة بيانات ثانية.
- تغيير الأسعار والأرصدة أو تأكيد الطلبات من التطبيق يتم عبر نفس Supabase الذي يستخدمه الموقع.

## إنشاء APK
افتح المجلد في Android Studio ثم Build > Build APK(s).

> ملاحظة: المشروع المصدر جاهز، لكن إنشاء APK يتطلب Android SDK/Gradle على جهاز البناء.

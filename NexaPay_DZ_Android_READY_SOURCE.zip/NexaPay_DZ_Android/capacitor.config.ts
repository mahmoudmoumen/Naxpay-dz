import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'dz.nexapay.app',
  appName: 'NexaPay DZ',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  }
};

export default config;
